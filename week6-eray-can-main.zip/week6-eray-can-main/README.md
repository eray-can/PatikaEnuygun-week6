## Lazy Loading ve Eager Loading arasındaki farkları yazınız.

Oluşturulan yeni bir entity model için varsayılan olarak tanımlı data yükleme yönetimidir. Eager loading Linq sorgusu çalıştırıldığında verilerin tamamını yükler ve hafızaya alır.

